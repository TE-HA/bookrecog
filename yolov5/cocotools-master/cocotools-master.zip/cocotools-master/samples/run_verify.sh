../tools/coco_verify.py nuts/trainval.json nuts/images nuts/verify
